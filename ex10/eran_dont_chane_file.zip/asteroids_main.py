from screen import Screen
import sys
import ship
import asteroid
import torpedo
import random
import math

DEFAULT_ASTEROIDS_NUM = 5
INITIAL_X_SPEED = 0
INITIAL_Y_SPEED = 0
INITIAL_DEG = 0


class GameRunner:

    def __init__(self, asteroids_amount):
        self.__screen = Screen()
        self.__torpedos = []

        self.__screen_max_x = Screen.SCREEN_MAX_X
        self.__screen_max_y = Screen.SCREEN_MAX_Y
        self.__screen_min_x = Screen.SCREEN_MIN_X
        self.__screen_min_y = Screen.SCREEN_MIN_Y

        # our code:
        x_rnd = random.randint(self.__screen_min_x, self.__screen_max_x)
        y_rnd = random.randint(self.__screen_min_y, self.__screen_max_y)
        self.__ship = ship.Ship(x_rnd, INITIAL_X_SPEED,
                                y_rnd, INITIAL_Y_SPEED, INITIAL_DEG)

        x_rnd = random.randint(self.__screen_min_x, self.__screen_max_x)
        y_rnd = random.randint(self.__screen_min_y, self.__screen_max_y)
        x_speed_rnd = random.randint(1, 4)
        y_speed_rnd = random.randint(1, 4)

        if asteroids_amount is None:
            asteroids_amount = 5

        self.__asteroids = [None] * asteroids_amount
        for i in range(asteroids_amount):
            a = asteroid.Asteroid(x_rnd, x_speed_rnd, y_rnd, y_speed_rnd, 3)
            self.__asteroids[i] = (a)
            self.__screen.register_asteroid(a, a.get_size())
            x_rnd = random.randint(self.__screen_min_x, self.__screen_max_x)
            y_rnd = random.randint(self.__screen_min_y, self.__screen_max_y)
            x_speed_rnd = random.randint(1, 4)
            y_speed_rnd = random.randint(1, 4)

    def run(self):
        self._do_loop()
        self.__screen.start_screen()

    def _do_loop(self):
        # You don't need to change this method!
        self._game_loop()

        # Set the timer to go off again
        self.__screen.update()
        self.__screen.ontimer(self._do_loop, 5)

    def _game_loop(self):
        # Your code goes here
        x, y = self.__ship.get_location()
        self.__screen.draw_ship(x, y, self.__ship.get_deg())
        self.move_object(self.__ship)
        self.keys_press()
        self.asteroid_draw(self.__asteroids)
        self.asteroids_move(self.__asteroids)
        if self.check_collision(self.__asteroids):
            self.__screen.show_message("SMASH!", "you hit an asteroid -1 life")
        self.torpedo_draw(self.__torpedos)
        self.torpedo_move(self.__torpedos)

    def torpedo_draw(self, torpedos):
        for tor in torpedos:
            self.__screen.draw_torpedo(tor, tor.get_location()[0],
                                       tor.get_location()[1], tor.get_deg())

    def torpedo_move(self, torpedos):
        for tor in torpedos:
            self.move_object(tor)

    def check_collision(self, asteroids):
        for asteroid in asteroids:
            if asteroid.has_intersection(self.__ship):
                self.__screen.unregister_asteroid(asteroid)
                asteroids.remove(asteroid)
                self.__screen.remove_life()
                return True
        return False

    def asteroids_move(self, asteroids):
        for asteroid in asteroids:
            self.move_object(asteroid)

    def asteroid_draw(self, asteroids):
        for asteroid in asteroids:
            self.__screen.draw_asteroid(asteroid,
                                        asteroid.get_location()[0],
                                        asteroid.get_location()[1])

    def keys_press(self):
        if self.__screen.is_left_pressed():
            self.rotate_ship(self.__ship, 0)

        elif self.__screen.is_right_pressed():
            self.rotate_ship(self.__ship, 1)

        elif self.__screen.is_up_pressed():
            self.accelerate_ship(self.__ship)

        elif self.__screen.is_space_pressed():
            self.shoot(self.__ship)

    def shoot(self, ship):
        x = ship.get_location()[0]
        y = ship.get_location()[1]
        old_x_speed = ship.get_speed()[0]
        old_y_speed = ship.get_speed()[1]
        deg = ship.get_deg()
        new_x_speed = old_x_speed + 2 * math.cos(deg * math.pi / 180)
        new_y_speed = old_y_speed + 2 * math.sin(deg * math.pi / 180)

        tor = torpedo.Torpedo(x, new_x_speed, y, new_y_speed, deg)
        self.__screen.register_torpedo(tor)
        self.__torpedos.append(tor)

    def accelerate_ship(self, ship):
        new_x_speed = ship.get_speed()[0] + math.cos(ship.get_deg() *
                                                     math.pi / 180)
        new_y_speed = ship.get_speed()[1] + math.sin(ship.get_deg() *
                                                     math.pi / 180)
        ship.set_speed(new_x_speed, new_y_speed)

    def rotate_ship(self, ship, direction):
        if direction == 1:
            ship.add_deg(-7)
        else:
            ship.add_deg(7)

    def move_object(self, ob):
        new_x = (ob.get_speed()[0] + ob.get_location()[0] -
                 self.__screen_min_x) % \
                (self.__screen_max_x - self.__screen_min_x) + \
                self.__screen_min_x
        new_y = (ob.get_speed()[1] + ob.get_location()[1] -
                 self.__screen_min_y) % \
                (self.__screen_max_y - self.__screen_min_y) + \
                self.__screen_min_y

        ob.set_location(new_x, new_y)


def main(amount):
    runner = GameRunner(amount)
    runner.run()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        main(int(sys.argv[1]))
    else:
        main(DEFAULT_ASTEROIDS_NUM)
