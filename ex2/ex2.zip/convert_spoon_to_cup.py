def convert_spoon_to_cup(num_of_spoons):
    """receives number of spoons to convert to cups.
    conversion factor: 1/16"""
    conversion_factor = 16
    return num_of_spoons/conversion_factor
